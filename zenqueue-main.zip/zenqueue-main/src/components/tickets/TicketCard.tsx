import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Clock, 
  AlertTriangle, 
  User, 
  Bell,
  Timer,
  Circle
} from "lucide-react";
import { useState, useEffect } from "react";

interface TicketCardProps {
  id: string;
  title: string;
  description: string;
  priority: "P1" | "P2" | "P3" | "P4";
  status: "unassigned" | "assigned" | "in_progress" | "pending" | "resolved";
  assignedTo?: string;
  assigneeStatus?: "active" | "working" | "pending" | "offline";
  createdAt: string;
  slaHours: number;
  estimatedResolution?: string;
  category: "incident" | "service_request";
  onAssign?: () => void;
  onNotify?: () => void;
}

export function TicketCard({ 
  id, 
  title, 
  description, 
  priority, 
  status, 
  assignedTo, 
  assigneeStatus,
  createdAt, 
  slaHours,
  estimatedResolution,
  category,
  onAssign,
  onNotify 
}: TicketCardProps) {
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [slaProgress, setSlaProgress] = useState(0);

  // SLA Timer Effect
  useEffect(() => {
    const interval = setInterval(() => {
      const created = new Date(createdAt).getTime();
      const now = new Date().getTime();
      const elapsed = Math.floor((now - created) / (1000 * 60 * 60)); // hours
      setTimeElapsed(elapsed);
      
      const progress = (elapsed / slaHours) * 100;
      setSlaProgress(Math.min(progress, 100));
    }, 60000); // Update every minute

    // Initial calculation
    const created = new Date(createdAt).getTime();
    const now = new Date().getTime();
    const elapsed = Math.floor((now - created) / (1000 * 60 * 60));
    setTimeElapsed(elapsed);
    setSlaProgress(Math.min((elapsed / slaHours) * 100, 100));

    return () => clearInterval(interval);
  }, [createdAt, slaHours]);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "P1": return "destructive";
      case "P2": return "warning";
      case "P3": return "default";
      case "P4": return "secondary";
      default: return "secondary";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "unassigned": return "destructive";
      case "assigned": return "warning";
      case "in_progress": return "default";
      case "pending": return "secondary";
      case "resolved": return "success";
      default: return "secondary";
    }
  };

  const getAssigneeStatusColor = (status?: string) => {
    switch (status) {
      case "active": return "text-success";
      case "working": return "text-warning";
      case "pending": return "text-muted-foreground";
      case "offline": return "text-destructive";
      default: return "text-muted-foreground";
    }
  };

  const formatTimeElapsed = (hours: number) => {
    if (hours < 1) return "< 1 hour";
    if (hours < 24) return `${hours} hours`;
    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;
    return `${days}d ${remainingHours}h`;
  };

  const shouldNotify = (priority === "P1" || priority === "P2") && status === "unassigned";

  return (
    <Card className={`transition-all duration-300 hover:shadow-lg ${shouldNotify ? 'border-destructive animate-pulse' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <CardTitle className="text-lg text-foreground">{title}</CardTitle>
              {shouldNotify && (
                <Bell className="w-4 h-4 text-destructive animate-bounce" />
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant={getPriorityColor(priority) as any}>
                {priority}
              </Badge>
              <Badge variant={getStatusColor(status) as any}>
                {status.replace('_', ' ')}
              </Badge>
              <Badge variant="outline">
                {category.replace('_', ' ')}
              </Badge>
              <span className="text-xs text-muted-foreground">#{id}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {status === "unassigned" && onAssign && (
              <Button variant="outline" size="sm" onClick={onAssign}>
                Assign
              </Button>
            )}
            {shouldNotify && onNotify && (
              <Button variant="destructive" size="sm" onClick={onNotify}>
                <Bell className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">{description}</p>
        
        {/* Assignee Info */}
        {assignedTo && (
          <div className="flex items-center justify-between p-2 rounded bg-muted/50">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span className="text-sm">{assignedTo}</span>
            </div>
            {assigneeStatus && (
              <div className="flex items-center gap-1">
                <Circle className={`w-2 h-2 fill-current ${getAssigneeStatusColor(assigneeStatus)}`} />
                <span className={`text-xs ${getAssigneeStatusColor(assigneeStatus)}`}>
                  {assigneeStatus}
                </span>
              </div>
            )}
          </div>
        )}

        {/* SLA Timer */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Timer className="w-4 h-4" />
              <span className="text-sm font-medium">SLA Timer</span>
            </div>
            <span className="text-xs text-muted-foreground">
              {formatTimeElapsed(timeElapsed)} / {slaHours}h
            </span>
          </div>
          <Progress 
            value={slaProgress} 
            className={`h-2 ${slaProgress > 80 ? 'bg-destructive' : slaProgress > 60 ? 'bg-warning' : 'bg-success'}`}
          />
          {slaProgress > 100 && (
            <div className="flex items-center gap-1 text-destructive">
              <AlertTriangle className="w-4 h-4" />
              <span className="text-xs font-medium">SLA Breached</span>
            </div>
          )}
        </div>

        {/* Timestamps */}
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Created: {new Date(createdAt).toLocaleString()}
          </span>
          {estimatedResolution && (
            <span>Est. Resolution: {estimatedResolution}</span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}