import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  estimatedTime: string;
  popularity: "high" | "medium" | "low";
  onRequest: () => void;
}

export function ServiceCard({ 
  title, 
  description, 
  icon: Icon, 
  category, 
  estimatedTime, 
  popularity,
  onRequest 
}: ServiceCardProps) {
  const getPopularityColor = () => {
    switch (popularity) {
      case "high":
        return "success";
      case "medium":
        return "warning";
      default:
        return "secondary";
    }
  };

  return (
    <Card className="magic-card animate-scale-in">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
              <Icon className="w-5 h-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">{title}</CardTitle>
              <CardDescription className="text-sm">{category}</CardDescription>
            </div>
          </div>
          <Badge variant={getPopularityColor() as any}>
            {popularity} demand
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">{description}</p>
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            Est. time: {estimatedTime}
          </span>
          <Button onClick={onRequest} size="sm" variant="hero">
            Request Service
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}