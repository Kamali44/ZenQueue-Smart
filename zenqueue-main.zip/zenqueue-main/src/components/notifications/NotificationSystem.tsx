import { useEffect, useState } from "react";
import { toast } from "@/hooks/use-toast";
import { Bell, AlertTriangle, User, Clock } from "lucide-react";

interface Ticket {
  id: string;
  title: string;
  priority: "P1" | "P2" | "P3" | "P4";
  status: "unassigned" | "assigned" | "in_progress" | "pending" | "resolved";
  assignedTo?: string;
  createdAt: string;
}

interface NotificationSystemProps {
  tickets: Ticket[];
  activeMembers: string[];
}

export function NotificationSystem({ tickets, activeMembers }: NotificationSystemProps) {
  const [notifiedTickets, setNotifiedTickets] = useState<Set<string>>(new Set());

  useEffect(() => {
    // Check for unassigned P1/P2 tickets
    const urgentUnassigned = tickets.filter(
      ticket => 
        (ticket.priority === "P1" || ticket.priority === "P2") && 
        ticket.status === "unassigned" &&
        !notifiedTickets.has(ticket.id)
    );

    urgentUnassigned.forEach(ticket => {
      toast({
        title: "Urgent Ticket Requires Assignment",
        description: `${ticket.priority} ticket "${ticket.title}" needs immediate attention`,
        variant: "destructive",
      });
      
      setNotifiedTickets(prev => new Set([...prev, ticket.id]));
    });

    // Check for newly assigned tickets
    const newlyAssigned = tickets.filter(
      ticket => 
        ticket.status === "assigned" && 
        ticket.assignedTo &&
        !notifiedTickets.has(`assigned-${ticket.id}`)
    );

    newlyAssigned.forEach(ticket => {
      toast({
        title: "New Ticket Assigned",
        description: `Ticket "${ticket.title}" has been assigned to ${ticket.assignedTo}`,
        variant: "default",
      });
      
      setNotifiedTickets(prev => new Set([...prev, `assigned-${ticket.id}`]));
    });

  }, [tickets, notifiedTickets]);

  // Auto-assign unassigned tickets to available members
  const autoAssignTickets = () => {
    const unassignedTickets = tickets.filter(ticket => ticket.status === "unassigned");
    const availableMembers = activeMembers.filter(member => 
      !tickets.some(ticket => ticket.assignedTo === member && ticket.status === "in_progress")
    );

    if (unassignedTickets.length > 0 && availableMembers.length > 0) {
      unassignedTickets.forEach((ticket, index) => {
        const assignedMember = availableMembers[index % availableMembers.length];
        
        toast({
          title: "Ticket Auto-Assigned",
          description: `Ticket "${ticket.title}" has been automatically assigned to ${assignedMember}`,
          variant: "default",
        });
      });
    }
  };

  useEffect(() => {
    // Auto-assign tickets every 5 minutes
    const assignInterval = setInterval(autoAssignTickets, 5 * 60 * 1000);
    
    // Notify about unassigned tickets every 30 minutes
    const notifyInterval = setInterval(() => {
      const unassignedTickets = tickets.filter(ticket => ticket.status === "unassigned");
      
      if (unassignedTickets.length > 0) {
        toast({
          title: "Unassigned Tickets Alert",
          description: `${unassignedTickets.length} ticket(s) are still unassigned and need attention`,
          variant: "destructive",
        });
      }
    }, 30 * 60 * 1000); // 30 minutes

    return () => {
      clearInterval(assignInterval);
      clearInterval(notifyInterval);
    };
  }, [tickets, activeMembers]);

  return null; // This component doesn't render anything visible
}