import { AppLayout } from "@/components/layout/AppLayout";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  TrendingUp, 
  Award, 
  Users, 
  Clock,
  Globe,
  BarChart3,
  Calendar,
  Trophy,
  UserCheck,
  Timer
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart, Line } from "recharts";
import { useState } from "react";

const Analytics = () => {
  const [selectedMonth, setSelectedMonth] = useState("current");
  const [comparisonMonth, setComparisonMonth] = useState("previous");

  // Top resolvers data
  const topResolvers = [
    { name: "John Smith", tickets: 47, avgTime: "2.3h", satisfaction: 4.8, status: "active" },
    { name: "Sarah Wilson", tickets: 43, avgTime: "2.1h", satisfaction: 4.9, status: "working" },
    { name: "Mike Johnson", tickets: 39, avgTime: "2.7h", satisfaction: 4.6, status: "active" },
    { name: "Emily Davis", tickets: 35, avgTime: "2.5h", satisfaction: 4.7, status: "pending" },
    { name: "Alex Brown", tickets: 31, avgTime: "3.1h", satisfaction: 4.5, status: "active" }
  ];

  // Monthly comparison data
  const monthlyComparison = [
    { month: "Dec 2023", tickets: 245, resolved: 230, avgTime: 3.2 },
    { month: "Jan 2024", tickets: 287, resolved: 275, avgTime: 2.8 }
  ];

  // Shift data
  const shiftMembers = {
    current: [
      { name: "John Smith", shift: "Morning", timezone: "EST", status: "active" },
      { name: "Sarah Wilson", shift: "Afternoon", timezone: "PST", status: "working" },
      { name: "Mike Johnson", shift: "Evening", timezone: "GMT", status: "active" }
    ],
    upcoming: [
      { name: "Emily Davis", shift: "Night", timezone: "EST", starts: "10:00 PM" },
      { name: "Alex Brown", shift: "Morning", timezone: "PST", starts: "6:00 AM" },
      { name: "Lisa Chen", shift: "Afternoon", timezone: "GMT", starts: "2:00 PM" }
    ]
  };

  // User data by country and timezone
  const usersByLocation = [
    { country: "United States", users: 145, timezone: "EST/PST", tickets: 89, value: 35 },
    { country: "United Kingdom", users: 98, timezone: "GMT", tickets: 67, value: 25 },
    { country: "Germany", users: 76, timezone: "CET", tickets: 45, value: 18 },
    { country: "Canada", users: 54, timezone: "EST", tickets: 32, value: 13 },
    { country: "Australia", users: 43, timezone: "AEST", tickets: 28, value: 9 }
  ];

  const COLORS = ['hsl(var(--primary))', 'hsl(var(--accent))', 'hsl(var(--secondary))', 'hsl(var(--muted))', 'hsl(var(--warning))'];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "success";
      case "working": return "warning";
      case "pending": return "secondary";
      default: return "secondary";
    }
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Analytics Dashboard</h1>
            <p className="text-muted-foreground">Performance insights and team analytics</p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current">Jan 2024</SelectItem>
                <SelectItem value="previous">Dec 2023</SelectItem>
                <SelectItem value="november">Nov 2023</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Calendar className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <MetricCard
            title="Total Tickets"
            value="287"
            change="+15.3% from last month"
            changeType="positive"
            icon={BarChart3}
          />
          <MetricCard
            title="Resolution Rate"
            value="95.8%"
            change="+2.4% from last month"
            changeType="positive"
            icon={TrendingUp}
          />
          <MetricCard
            title="Avg Resolution Time"
            value="2.8h"
            change="-0.4h from last month"
            changeType="positive"
            icon={Clock}
          />
          <MetricCard
            title="Active Team Members"
            value="12"
            change="Same as last month"
            changeType="neutral"
            icon={Users}
          />
        </div>

        {/* Top Resolver of the Month */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-warning" />
              Top Resolver of the Month
            </CardTitle>
            <CardDescription>Outstanding performance recognition</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-warning/10 to-accent/10 rounded-lg border border-warning/20">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-warning/20 rounded-full flex items-center justify-center">
                  <Award className="w-8 h-8 text-warning" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground">{topResolvers[0].name}</h3>
                  <p className="text-muted-foreground">IT Support Specialist</p>
                  <div className="flex items-center gap-4 mt-2">
                    <Badge variant="destructive">{topResolvers[0].tickets} tickets resolved</Badge>
                    <Badge variant="outline">{topResolvers[0].avgTime} avg time</Badge>
                    <Badge variant="outline">⭐ {topResolvers[0].satisfaction} satisfaction</Badge>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-warning">🏆</p>
                <p className="text-sm text-muted-foreground">January 2024</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Team Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Team Performance Leaderboard</CardTitle>
              <CardDescription>Top performing team members this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topResolvers.map((resolver, index) => (
                  <div key={resolver.name} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{resolver.name}</p>
                        <div className="flex items-center gap-2">
                          <Badge variant={getStatusColor(resolver.status) as any} className="text-xs">
                            {resolver.status}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            ⭐ {resolver.satisfaction}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-foreground">{resolver.tickets}</p>
                      <p className="text-xs text-muted-foreground">{resolver.avgTime}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Monthly Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>Monthly Ticket Flow Comparison</CardTitle>
              <CardDescription>Compare performance across months</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyComparison}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--foreground))" />
                  <YAxis stroke="hsl(var(--foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px'
                    }} 
                  />
                  <Legend />
                  <Bar dataKey="tickets" fill="hsl(var(--primary))" name="Total Tickets" />
                  <Bar dataKey="resolved" fill="hsl(var(--accent))" name="Resolved" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Shift Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="w-5 h-5" />
                Shift Team Management
              </CardTitle>
              <CardDescription>Current and upcoming shift schedules</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Current Shift
                </h4>
                <div className="space-y-2">
                  {shiftMembers.current.map((member) => (
                    <div key={member.name} className="flex items-center justify-between p-2 rounded bg-muted/30">
                      <div>
                        <p className="font-medium text-foreground">{member.name}</p>
                        <p className="text-xs text-muted-foreground">{member.timezone}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{member.shift}</Badge>
                        <Badge variant={getStatusColor(member.status) as any}>
                          {member.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <Timer className="w-4 h-4" />
                  Upcoming Shifts
                </h4>
                <div className="space-y-2">
                  {shiftMembers.upcoming.map((member) => (
                    <div key={member.name} className="flex items-center justify-between p-2 rounded bg-muted/30">
                      <div>
                        <p className="font-medium text-foreground">{member.name}</p>
                        <p className="text-xs text-muted-foreground">{member.timezone}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{member.shift}</Badge>
                        <span className="text-xs text-muted-foreground">{member.starts}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Global User Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Global User Distribution
              </CardTitle>
              <CardDescription>Frequent ticket users by country and timezone</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={usersByLocation}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {usersByLocation.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>

                <div className="space-y-2">
                  {usersByLocation.map((location, index) => (
                    <div key={location.country} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span className="font-medium">{location.country}</span>
                        <Badge variant="outline" className="text-xs">{location.timezone}</Badge>
                      </div>
                      <div className="flex items-center gap-3 text-muted-foreground">
                        <span>{location.users} users</span>
                        <span>{location.tickets} tickets</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default Analytics;