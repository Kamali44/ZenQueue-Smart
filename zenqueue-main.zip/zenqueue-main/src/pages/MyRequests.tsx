import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  XCircle,
  Eye,
  MessageSquare,
  Calendar
} from "lucide-react";

const MyRequests = () => {
  const requests = [
    {
      id: "REQ-001",
      title: "Software Installation - Adobe Creative Suite",
      category: "IT Services",
      status: "in_progress",
      priority: "medium",
      createdAt: "2024-01-15",
      estimatedCompletion: "2024-01-16",
      assignedTo: "IT Support Team",
      description: "Installation of Adobe Creative Suite for graphic design work"
    },
    {
      id: "REQ-002",
      title: "Access Request - Marketing Database",
      category: "Security",
      status: "pending_approval",
      priority: "high",
      createdAt: "2024-01-14",
      estimatedCompletion: "2024-01-15",
      assignedTo: "Security Team",
      description: "Need read access to marketing analytics database"
    },
    {
      id: "REQ-003",
      title: "Hardware Request - External Monitor",
      category: "IT Services",
      status: "completed",
      priority: "low",
      createdAt: "2024-01-10",
      estimatedCompletion: "2024-01-12",
      assignedTo: "Hardware Team",
      description: "24-inch external monitor for dual display setup"
    },
    {
      id: "REQ-004",
      title: "Technical Support - Email Configuration",
      category: "Support",
      status: "cancelled",
      priority: "medium",
      createdAt: "2024-01-08",
      estimatedCompletion: "2024-01-09",
      assignedTo: "Support Team",
      description: "Configure email client with company settings"
    },
    {
      id: "REQ-005",
      title: "Account Management - Password Reset",
      category: "Security",
      status: "completed",
      priority: "high",
      createdAt: "2024-01-05",
      estimatedCompletion: "2024-01-05",
      assignedTo: "Security Team",
      description: "Emergency password reset for main account"
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-success" />;
      case "in_progress":
        return <Clock className="w-4 h-4 text-warning" />;
      case "pending_approval":
        return <AlertCircle className="w-4 h-4 text-warning" />;
      case "cancelled":
        return <XCircle className="w-4 h-4 text-destructive" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "success";
      case "in_progress":
        return "warning";
      case "pending_approval":
        return "warning";
      case "cancelled":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive";
      case "medium":
        return "warning";
      case "low":
        return "secondary";
      default:
        return "secondary";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatStatus = (status: string) => {
    return status.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">My Requests</h1>
            <p className="text-muted-foreground">Track and manage your service requests</p>
          </div>
          <Button variant="hero">
            Create New Request
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-warning" />
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-xl font-bold">1</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-warning" />
                <div>
                  <p className="text-sm text-muted-foreground">Pending</p>
                  <p className="text-xl font-bold">1</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-success" />
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-xl font-bold">2</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <XCircle className="w-4 h-4 text-destructive" />
                <div>
                  <p className="text-sm text-muted-foreground">Cancelled</p>
                  <p className="text-xl font-bold">1</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Requests List */}
        <div className="space-y-4">
          {requests.map((request) => (
            <Card key={request.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <CardTitle className="text-lg">{request.title}</CardTitle>
                      <Badge variant={getStatusColor(request.status) as any} className="flex items-center gap-1">
                        {getStatusIcon(request.status)}
                        {formatStatus(request.status)}
                      </Badge>
                      <Badge variant={getPriorityColor(request.priority) as any}>
                        {request.priority} priority
                      </Badge>
                    </div>
                    <CardDescription className="flex items-center gap-4 text-sm">
                      <span>#{request.id}</span>
                      <span>•</span>
                      <span>{request.category}</span>
                      <span>•</span>
                      <span>Assigned to {request.assignedTo}</span>
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    <Button variant="outline" size="sm">
                      <MessageSquare className="w-4 h-4 mr-1" />
                      Chat
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground mb-4">{request.description}</p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      Created: {formatDate(request.createdAt)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Expected: {formatDate(request.estimatedCompletion)}
                    </span>
                  </div>
                  {request.status === "in_progress" && (
                    <Badge variant="outline" className="text-xs">
                      Estimated completion in 2 hours
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default MyRequests;