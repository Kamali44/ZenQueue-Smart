import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  BookOpen, 
  FileText, 
  PlusCircle,
  TrendingUp,
  Clock,
  Users,
  Star,
  MessageSquare
} from "lucide-react";
import { useState } from "react";

const KnowledgeBase = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const frequentTickets = [
    {
      id: "KB-001",
      title: "Password Reset Procedure",
      description: "Step-by-step guide for resetting user passwords and common troubleshooting steps",
      category: "Authentication",
      frequency: 45,
      lastUpdated: "2024-01-10",
      author: "John Smith",
      likes: 32,
      views: 156
    },
    {
      id: "KB-002", 
      title: "VPN Connection Setup",
      description: "Complete guide for setting up VPN connections across different operating systems",
      category: "Network",
      frequency: 38,
      lastUpdated: "2024-01-08",
      author: "Sarah Wilson",
      likes: 28,
      views: 134
    },
    {
      id: "KB-003",
      title: "Software Installation Issues",
      description: "Common software installation problems and their resolutions",
      category: "Software",
      frequency: 31,
      lastUpdated: "2024-01-12",
      author: "Mike Johnson",
      likes: 25,
      views: 98
    },
    {
      id: "KB-004",
      title: "Email Configuration Problems",
      description: "Troubleshooting email client configurations and sync issues",
      category: "Email",
      frequency: 29,
      lastUpdated: "2024-01-09",
      author: "Emily Davis",
      likes: 22,
      views: 87
    },
    {
      id: "KB-005",
      title: "Printer Connectivity Issues",
      description: "Resolving printer connection problems and driver issues",
      category: "Hardware",
      frequency: 24,
      lastUpdated: "2024-01-11",
      author: "John Smith",
      likes: 19,
      views: 76
    }
  ];

  const articles = [
    {
      id: "ART-001",
      title: "Best Practices for Incident Response",
      description: "Guidelines for effective incident management and response procedures",
      category: "Process",
      author: "IT Leadership Team",
      lastUpdated: "2024-01-14",
      readTime: "8 min read",
      difficulty: "Intermediate"
    },
    {
      id: "ART-002",
      title: "Security Protocols and Guidelines",
      description: "Comprehensive security protocols for handling sensitive data and systems",
      category: "Security",
      author: "Security Team", 
      lastUpdated: "2024-01-13",
      readTime: "12 min read",
      difficulty: "Advanced"
    },
    {
      id: "ART-003",
      title: "Customer Communication Templates",
      description: "Standardized templates for communicating with users during incidents",
      category: "Communication",
      author: "Customer Success Team",
      lastUpdated: "2024-01-12",
      readTime: "5 min read",
      difficulty: "Beginner"
    }
  ];

  const filteredTickets = frequentTickets.filter(ticket =>
    ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ticket.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ticket.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredArticles = articles.filter(article =>
    article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    article.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    article.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Knowledge Base</h1>
            <p className="text-muted-foreground">Access documentation, solutions, and team insights</p>
          </div>
          <Button variant="hero" className="flex items-center gap-2">
            <PlusCircle className="w-4 h-4" />
            Add Article
          </Button>
        </div>

        {/* Search */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              Search Knowledge Base
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search articles, solutions, or categories..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Content Tabs */}
        <Tabs defaultValue="frequent" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="frequent" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Frequent Issues
            </TabsTrigger>
            <TabsTrigger value="articles" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Documentation
            </TabsTrigger>
            <TabsTrigger value="create" className="flex items-center gap-2">
              <PlusCircle className="w-4 h-4" />
              Contribute
            </TabsTrigger>
          </TabsList>

          <TabsContent value="frequent" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">Most Frequent Tickets & Solutions</h2>
              <p className="text-sm text-muted-foreground">
                {filteredTickets.length} solution{filteredTickets.length !== 1 ? 's' : ''} found
              </p>
            </div>

            <div className="grid gap-4">
              {filteredTickets.map((ticket) => (
                <Card key={ticket.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{ticket.title}</CardTitle>
                        <CardDescription>{ticket.description}</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{ticket.category}</Badge>
                        <Badge variant="outline" className="flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          {ticket.frequency} tickets
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {ticket.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Updated {new Date(ticket.lastUpdated).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3" />
                          {ticket.likes}
                        </span>
                        <span>{ticket.views} views</span>
                        <Button variant="outline" size="sm">
                          View Solution
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="articles" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">Documentation & Articles</h2>
              <p className="text-sm text-muted-foreground">
                {filteredArticles.length} article{filteredArticles.length !== 1 ? 's' : ''} found
              </p>
            </div>

            <div className="grid gap-4">
              {filteredArticles.map((article) => (
                <Card key={article.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{article.title}</CardTitle>
                        <CardDescription>{article.description}</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{article.category}</Badge>
                        <Badge variant="outline">{article.difficulty}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {article.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {article.readTime}
                        </span>
                        <span>Updated {new Date(article.lastUpdated).toLocaleDateString()}</span>
                      </div>
                      <Button variant="outline" size="sm">
                        Read Article
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="create" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Contribute to Knowledge Base</CardTitle>
                <CardDescription>
                  Help improve our knowledge base by documenting solutions and sharing insights
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <BookOpen className="w-6 h-6 text-primary" />
                      <h3 className="font-semibold">Document a Solution</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Create detailed documentation for frequently encountered issues
                    </p>
                    <Button variant="outline" className="w-full">
                      Create Solution
                    </Button>
                  </Card>

                  <Card className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <MessageSquare className="w-6 h-6 text-primary" />
                      <h3 className="font-semibold">Share Best Practices</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Share your expertise and best practices with the team
                    </p>
                    <Button variant="outline" className="w-full">
                      Write Article
                    </Button>
                  </Card>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Recent Contributions</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>John Smith documented "Database Connection Issues"</span>
                      <span className="text-muted-foreground">2 hours ago</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Sarah Wilson updated "Email Configuration Guide"</span>
                      <span className="text-muted-foreground">1 day ago</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Mike Johnson added "Mobile Device Setup"</span>
                      <span className="text-muted-foreground">2 days ago</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default KnowledgeBase;