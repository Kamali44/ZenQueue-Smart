import { AppLayout } from "@/components/layout/AppLayout";
import { ServiceCard } from "@/components/dashboard/ServiceCard";
import { TicketCard } from "@/components/tickets/TicketCard";
import { NotificationSystem } from "@/components/notifications/NotificationSystem";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Filter, 
  Laptop, 
  Shield, 
  Database, 
  Headphones,
  Wifi,
  Monitor,
  Smartphone,
  Cloud,
  Users,
  Settings,
  BookOpen,
  FileText,
  AlertTriangle,
  Plus
} from "lucide-react";
import { useState } from "react";

const ServiceCatalog = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [activeTab, setActiveTab] = useState("services");

  const categories = [
    { id: "all", name: "All Services", count: 12 },
    { id: "it", name: "IT Services", count: 6 },
    { id: "security", name: "Security", count: 3 },
    { id: "support", name: "Support", count: 2 },
    { id: "hr", name: "HR Services", count: 1 },
  ];

  const services = [
    {
      title: "Software Installation",
      description: "Request installation of approved software applications including Microsoft Office, Adobe Creative Suite, development tools, and business applications.",
      icon: Laptop,
      category: "IT Services",
      estimatedTime: "2-4 hours",
      popularity: "high" as const
    },
    {
      title: "Access Request",
      description: "Request access to systems, applications, databases, or network resources. Includes VPN access, application permissions, and security clearances.",
      icon: Shield,
      category: "Security",
      estimatedTime: "1-2 hours",
      popularity: "high" as const
    },
    {
      title: "Hardware Request",
      description: "Request new hardware including laptops, desktops, monitors, keyboards, mice, and other IT equipment for your workspace.",
      icon: Database,
      category: "IT Services",
      estimatedTime: "1-3 days",
      popularity: "medium" as const
    },
    {
      title: "Technical Support",
      description: "Get help with technical issues, troubleshooting, software problems, hardware malfunctions, and general IT assistance.",
      icon: Headphones,
      category: "Support",
      estimatedTime: "30 min - 2 hours",
      popularity: "high" as const
    },
    {
      title: "Network Setup",
      description: "Configure network connections, WiFi access, ethernet setup, and network troubleshooting for your devices.",
      icon: Wifi,
      category: "IT Services",
      estimatedTime: "1-2 hours",
      popularity: "medium" as const
    },
    {
      title: "Monitor Setup",
      description: "Request additional monitors, dual monitor setup, monitor calibration, and display configuration for enhanced productivity.",
      icon: Monitor,
      category: "IT Services",
      estimatedTime: "30-60 minutes",
      popularity: "medium" as const
    },
    {
      title: "Mobile Device Setup",
      description: "Configure company smartphones, tablets, mobile app installation, and mobile security setup for remote work.",
      icon: Smartphone,
      category: "IT Services",
      estimatedTime: "1-2 hours",
      popularity: "low" as const
    },
    {
      title: "Cloud Storage Access",
      description: "Request access to cloud storage solutions, file sharing permissions, and cloud application setup for collaboration.",
      icon: Cloud,
      category: "IT Services",
      estimatedTime: "30 minutes",
      popularity: "medium" as const
    },
    {
      title: "Account Management",
      description: "User account creation, password resets, account permissions, profile updates, and directory management services.",
      icon: Users,
      category: "Security",
      estimatedTime: "15-30 minutes",
      popularity: "high" as const
    },
    {
      title: "System Configuration",
      description: "Custom system settings, software configuration, environment setup, and personalized workspace configuration.",
      icon: Settings,
      category: "Support",
      estimatedTime: "1-3 hours",
      popularity: "low" as const
    },
    {
      title: "Training & Documentation",
      description: "Access to training materials, user guides, best practices documentation, and skill development resources.",
      icon: BookOpen,
      category: "HR Services",
      estimatedTime: "Varies",
      popularity: "medium" as const
    },
    {
      title: "Data Recovery",
      description: "Recover lost files, backup restoration, data migration services, and emergency data recovery assistance.",
      icon: FileText,
      category: "Security",
      estimatedTime: "2-8 hours",
      popularity: "low" as const
    }
  ];

  const filteredServices = services.filter(service => {
    const matchesSearch = service.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || 
                           service.category.toLowerCase().includes(selectedCategory);
    return matchesSearch && matchesCategory;
  });

  // Sample incidents data
  const incidents = [
    {
      id: "INC-001",
      title: "Email Server Outage",
      description: "Company-wide email service is experiencing intermittent connectivity issues",
      priority: "P1" as const,
      status: "unassigned" as const,
      createdAt: "2024-01-15T10:30:00Z",
      slaHours: 4,
      category: "incident" as const
    },
    {
      id: "INC-002", 
      title: "VPN Connection Issues",
      description: "Multiple users reporting inability to connect to corporate VPN",
      priority: "P2" as const,
      status: "assigned" as const,
      assignedTo: "John Smith",
      assigneeStatus: "working" as const,
      createdAt: "2024-01-15T09:15:00Z",
      slaHours: 8,
      category: "incident" as const
    },
    {
      id: "INC-003",
      title: "Printer Connectivity",
      description: "Floor 3 printers not responding to print requests",
      priority: "P3" as const,
      status: "in_progress" as const,
      assignedTo: "Sarah Wilson",
      assigneeStatus: "active" as const,
      createdAt: "2024-01-15T08:45:00Z",
      slaHours: 24,
      category: "incident" as const
    }
  ];

  const activeMembers = ["John Smith", "Sarah Wilson", "Mike Johnson", "Emily Davis"];

  const handleServiceRequest = (serviceName: string) => {
    console.log(`Requesting service: ${serviceName}`);
    // TODO: Navigate to service request form
  };

  const handleTicketAssign = (ticketId: string) => {
    console.log(`Assigning ticket: ${ticketId}`);
    // TODO: Implement ticket assignment logic
  };

  const handleTicketNotify = (ticketId: string) => {
    console.log(`Notifying about ticket: ${ticketId}`);
    // TODO: Send notification
  };

  return (
    <AppLayout>
      <NotificationSystem tickets={incidents} activeMembers={activeMembers} />
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Service Catalog & Incidents</h1>
          <p className="text-muted-foreground">Browse services and manage incidents from a unified platform</p>
        </div>

        {/* Tabs for Services and Incidents */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="services">Service Catalog</TabsTrigger>
            <TabsTrigger value="incidents" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Incidents ({incidents.filter(i => i.status === "unassigned").length} unassigned)
            </TabsTrigger>
          </TabsList>

          <TabsContent value="services" className="space-y-6">

            {/* Search and Filters */}
            <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              Find Services
            </CardTitle>
            <CardDescription>
              Search through our available services or browse by category
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search services, descriptions, or keywords..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center gap-2"
                >
                  {category.name}
                  <Badge variant="secondary" className="ml-1">
                    {category.count}
                  </Badge>
                </Button>
              ))}
            </div>
          </CardContent>
            </Card>

            {/* Services Grid */}
            <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">
              {selectedCategory === "all" ? "All Services" : categories.find(c => c.id === selectedCategory)?.name}
            </h2>
            <p className="text-sm text-muted-foreground">
              {filteredServices.length} service{filteredServices.length !== 1 ? 's' : ''} found
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service, index) => (
              <ServiceCard 
                key={index} 
                {...service} 
                onRequest={() => handleServiceRequest(service.title)}
              />
            ))}
          </div>

              {filteredServices.length === 0 && (
                <Card className="text-center py-12">
                  <CardContent>
                    <div className="flex flex-col items-center gap-4">
                      <Search className="w-12 h-12 text-muted-foreground" />
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">No services found</h3>
                        <p className="text-muted-foreground">Try adjusting your search terms or category filters</p>
                      </div>
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setSearchTerm("");
                          setSelectedCategory("all");
                        }}
                      >
                        Clear Filters
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="incidents" className="space-y-6">
            {/* Incidents Header */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground">Incident Management</h2>
                <p className="text-muted-foreground">Monitor and resolve system incidents</p>
              </div>
              <Button variant="hero" className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Report Incident
              </Button>
            </div>

            {/* Incident Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-destructive" />
                    <div>
                      <p className="text-sm text-muted-foreground">Unassigned</p>
                      <p className="text-2xl font-bold text-destructive">
                        {incidents.filter(i => i.status === "unassigned").length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-warning" />
                    <div>
                      <p className="text-sm text-muted-foreground">In Progress</p>
                      <p className="text-2xl font-bold text-warning">
                        {incidents.filter(i => i.status === "in_progress").length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">P1/P2 Critical</p>
                      <p className="text-2xl font-bold text-primary">
                        {incidents.filter(i => i.priority === "P1" || i.priority === "P2").length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-success" />
                    <div>
                      <p className="text-sm text-muted-foreground">Available Team</p>
                      <p className="text-2xl font-bold text-success">{activeMembers.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Incidents List */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-foreground">Active Incidents</h3>
              {incidents.map((incident) => (
                <TicketCard
                  key={incident.id}
                  {...incident}
                  onAssign={() => handleTicketAssign(incident.id)}
                  onNotify={() => handleTicketNotify(incident.id)}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default ServiceCatalog;