import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Star, 
  Users, 
  Clock, 
  Calendar,
  CheckCircle,
  TrendingUp,
  Award,
  Timer,
  UserCheck,
  Coffee,
  Zap,
  Target,
  Crown
} from "lucide-react";

const InternalTeam = () => {
  const topPerformers = [
    {
      id: 1,
      name: "Sarah Chen",
      role: "Senior Support Engineer",
      avatar: "/api/placeholder/40/40",
      ticketsResolved: 247,
      rating: 4.9,
      specialties: ["Hardware", "Network", "Security"],
      status: "online",
      responseTime: "2.3 min",
      satisfactionRate: 98
    },
    {
      id: 2,
      name: "Alex Rodriguez",
      role: "IT Specialist",
      avatar: "/api/placeholder/40/40",
      ticketsResolved: 189,
      rating: 4.8,
      specialties: ["Software", "Cloud", "Database"],
      status: "online",
      responseTime: "3.1 min",
      satisfactionRate: 96
    },
    {
      id: 3,
      name: "Maya Patel",
      role: "Security Analyst",
      avatar: "/api/placeholder/40/40",
      ticketsResolved: 156,
      rating: 4.9,
      specialties: ["Security", "Access Control", "Compliance"],
      status: "busy",
      responseTime: "4.2 min",
      satisfactionRate: 97
    }
  ];

  const upcomingShifts = [
    {
      id: 1,
      name: "David Kim",
      role: "Support Engineer",
      avatar: "/api/placeholder/40/40",
      shiftStart: "09:00",
      shiftEnd: "17:00",
      timezone: "PST",
      status: "scheduled",
      coverage: ["Hardware", "Software"]
    },
    {
      id: 2,
      name: "Lisa Johnson",
      role: "Senior Analyst",
      avatar: "/api/placeholder/40/40",
      shiftStart: "13:00",
      shiftEnd: "21:00",
      timezone: "EST",
      status: "scheduled",
      coverage: ["Security", "Network"]
    },
    {
      id: 3,
      name: "Robert Zhang",
      role: "IT Specialist",
      avatar: "/api/placeholder/40/40",
      shiftStart: "01:00",
      shiftEnd: "09:00",
      timezone: "JST",
      status: "scheduled",
      coverage: ["Database", "Cloud"]
    }
  ];

  const availableTeam = [
    {
      id: 1,
      name: "Emma Wilson",
      role: "Support Engineer",
      avatar: "/api/placeholder/40/40",
      status: "available",
      currentLoad: 3,
      maxLoad: 8,
      skills: ["Software", "Hardware"],
      lastActive: "2 min ago"
    },
    {
      id: 2,
      name: "James Brown",
      role: "Security Specialist",
      avatar: "/api/placeholder/40/40",
      status: "available",
      currentLoad: 2,
      maxLoad: 6,
      skills: ["Security", "Compliance"],
      lastActive: "5 min ago"
    },
    {
      id: 3,
      name: "Anna Martinez",
      role: "IT Analyst",
      avatar: "/api/placeholder/40/40",
      status: "busy",
      currentLoad: 5,
      maxLoad: 7,
      skills: ["Network", "Cloud"],
      lastActive: "1 min ago"
    },
    {
      id: 4,
      name: "Michael Lee",
      role: "Support Lead",
      avatar: "/api/placeholder/40/40",
      status: "available",
      currentLoad: 4,
      maxLoad: 10,
      skills: ["Management", "Escalation"],
      lastActive: "Just now"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
      case "available":
        return "success";
      case "busy":
        return "warning";
      case "offline":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const getStatusDot = (status: string) => {
    const color = getStatusColor(status);
    return (
      <div className={`w-3 h-3 rounded-full ${
        color === "success" ? "bg-success" :
        color === "warning" ? "bg-warning" :
        color === "destructive" ? "bg-destructive" :
        "bg-muted"
      }`} />
    );
  };

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              <Users className="w-8 h-8 text-primary" />
              Internal Team Dashboard
            </h1>
            <p className="text-muted-foreground">Team performance, availability, and shift management</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="glow-button">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule
            </Button>
            <Button variant="hero" className="glow-button">
              <UserCheck className="w-4 h-4 mr-2" />
              Team Analytics
            </Button>
          </div>
        </div>

        {/* Top Performers Section */}
        <Card className="magic-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Trophy className="w-6 h-6 text-warning" />
              Top Performers This Month
            </CardTitle>
            <CardDescription>
              Team members with highest ticket resolution rates and customer satisfaction
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {topPerformers.map((performer, index) => (
                <Card 
                  key={performer.id} 
                  className={`magic-card relative overflow-hidden ${
                    index === 0 ? "ring-2 ring-warning" : ""
                  }`}
                >
                  {index === 0 && (
                    <div className="absolute top-0 right-0 bg-gradient-to-l from-warning to-warning/50 text-warning-foreground px-3 py-1 rounded-bl-lg">
                      <Crown className="w-4 h-4 inline mr-1" />
                      #1
                    </div>
                  )}
                  
                  <CardHeader className="text-center">
                    <div className="flex items-center justify-center mb-3">
                      <Avatar className="w-16 h-16 ring-2 ring-primary/20">
                        <AvatarImage src={performer.avatar} />
                        <AvatarFallback>{performer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      {getStatusDot(performer.status)}
                    </div>
                    <CardTitle className="text-lg">{performer.name}</CardTitle>
                    <CardDescription>{performer.role}</CardDescription>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary flex items-center justify-center gap-2">
                        <CheckCircle className="w-6 h-6" />
                        {performer.ticketsResolved}
                      </div>
                      <p className="text-sm text-muted-foreground">Tickets Resolved</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Star className="w-4 h-4 text-warning" />
                          <span className="font-semibold">{performer.rating}</span>
                        </div>
                        <p className="text-muted-foreground">Rating</p>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Timer className="w-4 h-4 text-primary" />
                          <span className="font-semibold">{performer.responseTime}</span>
                        </div>
                        <p className="text-muted-foreground">Avg Response</p>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Satisfaction Rate</span>
                        <span className="font-semibold">{performer.satisfactionRate}%</span>
                      </div>
                      <Progress value={performer.satisfactionRate} className="h-2" />
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {performer.specialties.map((specialty, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Available Team & Upcoming Shifts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Available Team Members */}
          <Card className="magic-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-success" />
                Available Team Members
              </CardTitle>
              <CardDescription>
                Current team availability and workload status
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {availableTeam.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-4 rounded-lg border bg-card hover:shadow-md transition-all">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={member.avatar} />
                        <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-1 -right-1">
                        {getStatusDot(member.status)}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold">{member.name}</h4>
                      <p className="text-sm text-muted-foreground">{member.role}</p>
                      <p className="text-xs text-muted-foreground">{member.lastActive}</p>
                    </div>
                  </div>
                  
                  <div className="text-right space-y-2">
                    <Badge variant={getStatusColor(member.status) as any}>
                      {member.status}
                    </Badge>
                    <div className="text-sm">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Load</span>
                        <span>{member.currentLoad}/{member.maxLoad}</span>
                      </div>
                      <Progress 
                        value={(member.currentLoad / member.maxLoad) * 100} 
                        className="h-1.5 w-16"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Upcoming Shifts */}
          <Card className="magic-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                Upcoming Shifts
              </CardTitle>
              <CardDescription>
                Next 24 hours shift schedule and coverage
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingShifts.map((shift) => (
                <div key={shift.id} className="flex items-center justify-between p-4 rounded-lg border bg-card hover:shadow-md transition-all">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={shift.avatar} />
                      <AvatarFallback>{shift.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold">{shift.name}</h4>
                      <p className="text-sm text-muted-foreground">{shift.role}</p>
                      <div className="flex gap-1 mt-1">
                        {shift.coverage.map((area, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {area}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="font-semibold text-sm">
                      {shift.shiftStart} - {shift.shiftEnd}
                    </div>
                    <p className="text-xs text-muted-foreground">{shift.timezone}</p>
                    <Badge variant="secondary" className="mt-1">
                      {shift.status}
                    </Badge>
                  </div>
                </div>
              ))}
              
              <Button variant="outline" className="w-full">
                <Calendar className="w-4 h-4 mr-2" />
                View Full Schedule
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Team Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="magic-card text-center">
            <CardContent className="p-6">
              <Target className="w-8 h-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold text-success">94%</div>
              <p className="text-sm text-muted-foreground">Team Efficiency</p>
            </CardContent>
          </Card>
          
          <Card className="magic-card text-center">
            <CardContent className="p-6">
              <Coffee className="w-8 h-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold text-warning">8</div>
              <p className="text-sm text-muted-foreground">Online Now</p>
            </CardContent>
          </Card>
          
          <Card className="magic-card text-center">
            <CardContent className="p-6">
              <Award className="w-8 h-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold text-primary">2.1h</div>
              <p className="text-sm text-muted-foreground">Avg Resolution</p>
            </CardContent>
          </Card>
          
          <Card className="magic-card text-center">
            <CardContent className="p-6">
              <TrendingUp className="w-8 h-8 text-accent-foreground mx-auto mb-2" />
              <div className="text-2xl font-bold text-accent-foreground">+12%</div>
              <p className="text-sm text-muted-foreground">This Week</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default InternalTeam;