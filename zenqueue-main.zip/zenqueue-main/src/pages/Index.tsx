import { AppLayout } from "@/components/layout/AppLayout";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { ServiceCard } from "@/components/dashboard/ServiceCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Ticket, 
  Clock, 
  CheckCircle, 
  Users, 
  Laptop, 
  Shield, 
  Database, 
  Headphones,
  FileText,
  TrendingUp,
  Activity
} from "lucide-react";

const Dashboard = () => {
  const metrics = [
    {
      title: "Open Tickets",
      value: "23",
      change: "+2 from yesterday",
      changeType: "negative" as const,
      icon: Ticket
    },
    {
      title: "Avg. Resolution Time",
      value: "4.2h",
      change: "-0.8h from last week",
      changeType: "positive" as const,
      icon: Clock
    },
    {
      title: "Service Satisfaction",
      value: "94%",
      change: "+2% from last month",
      changeType: "positive" as const,
      icon: CheckCircle
    },
    {
      title: "Active Users",
      value: "1,247",
      change: "+23 this week",
      changeType: "positive" as const,
      icon: Users
    }
  ];

  const popularServices = [
    {
      title: "Software Installation",
      description: "Request installation of approved software applications",
      icon: Laptop,
      category: "IT Services",
      estimatedTime: "2-4 hours",
      popularity: "high" as const
    },
    {
      title: "Access Request",
      description: "Request access to systems, applications, or resources",
      icon: Shield,
      category: "Security",
      estimatedTime: "1-2 hours",
      popularity: "high" as const
    },
    {
      title: "Hardware Request",
      description: "Request new hardware or replacement equipment",
      icon: Database,
      category: "IT Services",
      estimatedTime: "1-3 days",
      popularity: "medium" as const
    },
    {
      title: "Technical Support",
      description: "Get help with technical issues and troubleshooting",
      icon: Headphones,
      category: "Support",
      estimatedTime: "30 min - 2 hours",
      popularity: "high" as const
    }
  ];

  const handleServiceRequest = (serviceName: string) => {
    console.log(`Requesting service: ${serviceName}`);
    // TODO: Navigate to service request form
  };

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Welcome Section */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Welcome to Zenqueue</h1>
            <p className="text-muted-foreground">Your smart service management platform</p>
          </div>
          <Button variant="hero" size="lg" className="glow-button animate-bounce-in">
            <FileText className="w-4 h-4 mr-2" />
            Create Request
          </Button>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((metric, index) => (
            <MetricCard key={index} {...metric} />
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Popular Services */}
          <div className="lg:col-span-2">
            <Card className="magic-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Popular Services
                </CardTitle>
                <CardDescription>
                  Most requested services this week
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {popularServices.map((service, index) => (
                    <ServiceCard 
                      key={index} 
                      {...service} 
                      onRequest={() => handleServiceRequest(service.title)}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions & Activity */}
          <div className="space-y-6">
            {/* Recent Activity */}
            <Card className="magic-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3 hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <div className="w-2 h-2 bg-success rounded-full mt-2 animate-bounce-in"></div>
                  <div className="flex-1">
                    <p className="text-sm">Software installation completed</p>
                    <p className="text-xs text-muted-foreground">2 minutes ago</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <div className="w-2 h-2 bg-warning rounded-full mt-2"></div>
                  <div className="flex-1">
                    <p className="text-sm">Access request pending approval</p>
                    <p className="text-xs text-muted-foreground">15 minutes ago</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <div className="flex-1">
                    <p className="text-sm">New team member onboarded</p>
                    <p className="text-xs text-muted-foreground">1 hour ago</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <div className="w-2 h-2 bg-success rounded-full mt-2"></div>
                  <div className="flex-1">
                    <p className="text-sm">Hardware request delivered</p>
                    <p className="text-xs text-muted-foreground">3 hours ago</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="magic-card">
              <CardHeader>
                <CardTitle>Today's Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <span className="text-sm text-muted-foreground">Requests Created</span>
                  <span className="font-semibold">12</span>
                </div>
                <div className="flex justify-between items-center hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <span className="text-sm text-muted-foreground">Requests Resolved</span>
                  <span className="font-semibold text-success">18</span>
                </div>
                <div className="flex justify-between items-center hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <span className="text-sm text-muted-foreground">Team Online</span>
                  <span className="font-semibold text-primary">24</span>
                </div>
                <div className="flex justify-between items-center hover:bg-muted/50 p-2 rounded-lg transition-colors">
                  <span className="text-sm text-muted-foreground">Avg Response Time</span>
                  <span className="font-semibold">32min</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
