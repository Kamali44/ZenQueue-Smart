import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MessageSquare, 
  AlertTriangle, 
  Clock,
  User,
  Send,
  Search,
  Filter,
  Bell,
  Globe,
  MapPin
} from "lucide-react";
import { useState } from "react";

const TeamChat = () => {
  const [newMessage, setNewMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  // New scenario tickets from global users
  const newScenarioTickets = [
    {
      id: "SCN-001",
      title: "Unable to access company portal from mobile device",
      description: "User reporting issues accessing the company portal from their mobile device. Error message appears when trying to login.",
      userLocation: "London, UK",
      timezone: "GMT+0",
      priority: "P2",
      submittedAt: "2024-01-15T14:30:00Z",
      category: "Access Issue",
      userType: "Remote Employee",
      scenario: "New - Mobile Access Problem"
    },
    {
      id: "SCN-002", 
      title: "Integration failure between CRM and Email system",
      description: "Customer data is not syncing properly between our CRM system and email marketing platform.",
      userLocation: "New York, USA",
      timezone: "EST-5",
      priority: "P1",
      submittedAt: "2024-01-15T13:45:00Z",
      category: "Integration",
      userType: "Department Manager",
      scenario: "New - System Integration"
    },
    {
      id: "SCN-003",
      title: "Bulk user import process failing with CSV file",
      description: "Attempting to import 500+ users via CSV but process keeps failing at 60% completion.",
      userLocation: "Sydney, Australia", 
      timezone: "AEST+11",
      priority: "P2",
      submittedAt: "2024-01-15T12:20:00Z",
      category: "Data Import",
      userType: "HR Administrator",
      scenario: "New - Bulk Operation Issue"
    },
    {
      id: "SCN-004",
      title: "Unusual network latency affecting video conferences",
      description: "Multiple users reporting severe lag and connection drops during video conferences, specifically with external participants.",
      userLocation: "Mumbai, India",
      timezone: "IST+5:30", 
      priority: "P2",
      submittedAt: "2024-01-15T11:15:00Z",
      category: "Network Performance",
      userType: "Team Lead",
      scenario: "New - Performance Issue"
    },
    {
      id: "SCN-005",
      title: "Custom dashboard widgets not loading data",
      description: "Several dashboard widgets showing 'No Data Available' even though underlying data exists in the system.",
      userLocation: "Toronto, Canada",
      timezone: "EST-5",
      priority: "P3",
      submittedAt: "2024-01-15T10:30:00Z",
      category: "Dashboard",
      userType: "Business Analyst",
      scenario: "New - UI/Display Issue"
    }
  ];

  const chatMessages = [
    {
      id: 1,
      sender: "John Smith",
      message: "SCN-002 looks like a complex integration issue. I've seen similar problems before with CRM systems.",
      timestamp: "2024-01-15T14:45:00Z",
      ticketRef: "SCN-002"
    },
    {
      id: 2,
      sender: "Sarah Wilson", 
      message: "I can take a look at SCN-001. Mobile access issues are usually related to authentication tokens expiring.",
      timestamp: "2024-01-15T14:47:00Z",
      ticketRef: "SCN-001"
    },
    {
      id: 3,
      sender: "Mike Johnson",
      message: "The network latency issue in SCN-004 might be related to the recent infrastructure changes. Let me check the logs.",
      timestamp: "2024-01-15T14:50:00Z",
      ticketRef: "SCN-004"
    },
    {
      id: 4,
      sender: "Emily Davis",
      message: "For SCN-003, bulk imports usually fail due to data validation errors. We should check the error logs for specifics.",
      timestamp: "2024-01-15T14:52:00Z",
      ticketRef: "SCN-003"
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "P1": return "destructive";
      case "P2": return "warning";
      case "P3": return "default";
      default: return "secondary";
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const filteredTickets = newScenarioTickets.filter(ticket =>
    ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ticket.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ticket.userLocation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Team Chat</h1>
            <p className="text-muted-foreground">Collaborate on new scenario tickets from global users</p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="destructive" className="flex items-center gap-1">
              <Bell className="w-3 h-3" />
              {newScenarioTickets.filter(t => t.priority === "P1").length} urgent
            </Badge>
            <Badge variant="secondary">
              {newScenarioTickets.length} new scenarios
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* New Scenario Tickets */}
          <div className="lg:col-span-2 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  New Scenario Tickets
                </CardTitle>
                <CardDescription>Fresh challenges from global users requiring team expertise</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input 
                      placeholder="Search tickets by title, description, or location..." 
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {filteredTickets.map((ticket) => (
                    <Card key={ticket.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <CardTitle className="text-base">{ticket.title}</CardTitle>
                              <Badge variant={getPriorityColor(ticket.priority) as any}>
                                {ticket.priority}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                              <span>#{ticket.id}</span>
                              <span>•</span>
                              <Badge variant="outline" className="text-xs">{ticket.category}</Badge>
                              <span>•</span>
                              <span>{ticket.userType}</span>
                            </div>
                          </div>
                          <div className="text-right text-xs text-muted-foreground">
                            <div className="flex items-center gap-1 mb-1">
                              <MapPin className="w-3 h-3" />
                              {ticket.userLocation}
                            </div>
                            <div className="flex items-center gap-1">
                              <Globe className="w-3 h-3" />
                              {ticket.timezone}
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-sm text-muted-foreground mb-3">{ticket.description}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {ticket.scenario}
                            </Badge>
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {formatDate(ticket.submittedAt)}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              Claim
                            </Button>
                            <Button variant="default" size="sm">
                              Discuss
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Team Chat */}
          <div className="space-y-4">
            <Card className="h-96">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Team Discussion
                </CardTitle>
                <CardDescription>Real-time collaboration on scenario tickets</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-64 overflow-y-auto p-4 space-y-3">
                  {chatMessages.map((message) => (
                    <div key={message.id} className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-foreground">{message.sender}</span>
                        <span className="text-xs text-muted-foreground">{formatTime(message.timestamp)}</span>
                        {message.ticketRef && (
                          <Badge variant="outline" className="text-xs">
                            {message.ticketRef}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground pl-2 border-l-2 border-muted">
                        {message.message}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t">
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Share insights about scenario tickets..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          // Handle send message
                          setNewMessage("");
                        }
                      }}
                    />
                    <Button size="sm">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Today's Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">New Scenarios</span>
                  <Badge variant="secondary">{newScenarioTickets.length}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">P1 Critical</span>
                  <Badge variant="destructive">
                    {newScenarioTickets.filter(t => t.priority === "P1").length}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Countries</span>
                  <Badge variant="outline">
                    {new Set(newScenarioTickets.map(t => t.userLocation.split(',')[1]?.trim())).size}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Active Team</span>
                  <Badge variant="default">4 online</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default TeamChat;